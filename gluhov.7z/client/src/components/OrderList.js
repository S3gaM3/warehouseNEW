import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  TextField,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  Typography,
  Grid,
  CircularProgress,
  Alert,
  Snackbar,
  Chip,
  Select,
  MenuItem,
  FormControl,
  InputLabel
} from '@mui/material';
import { Edit as EditIcon, Delete as DeleteIcon, Add as AddIcon } from '@mui/icons-material';
import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

const INITIAL_FORM_DATA = {
  type: 'incoming',
  supplier_id: '',
  status: 'pending',
  notes: ''
};

const ORDER_TYPES = {
  incoming: { label: 'Входящий', color: 'success' },
  outgoing: { label: 'Исходящий', color: 'error' }
};

const ORDER_STATUSES = {
  pending: { label: 'В ожидании', color: 'warning' },
  processing: { label: 'В обработке', color: 'info' },
  completed: { label: 'Завершен', color: 'success' },
  cancelled: { label: 'Отменен', color: 'error' }
};

function OrderList() {
  const [orders, setOrders] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [open, setOpen] = useState(false);
  const [editingOrder, setEditingOrder] = useState(null);
  const [formData, setFormData] = useState(INITIAL_FORM_DATA);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);

  const fetchOrders = async () => {
    setLoading(true);
    try {
      const response = await axios.get(`${API_URL}/orders`);
      setOrders(response.data);
    } catch (error) {
      setError('Ошибка при получении заказов');
      console.error('Ошибка при получении заказов:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchSuppliers = async () => {
    try {
      const response = await axios.get(`${API_URL}/suppliers`);
      setSuppliers(response.data);
    } catch (error) {
      console.error('Ошибка при получении поставщиков:', error);
    }
  };

  useEffect(() => {
    fetchOrders();
    fetchSuppliers();
  }, []);

  const handleOpen = (order = null) => {
    if (order) {
      setEditingOrder(order);
      setFormData({
        type: order.type,
        supplier_id: order.supplier_id,
        status: order.status,
        notes: order.notes
      });
    } else {
      setEditingOrder(null);
      setFormData(INITIAL_FORM_DATA);
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingOrder(null);
    setFormData(INITIAL_FORM_DATA);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      if (editingOrder) {
        await axios.put(`${API_URL}/orders/${editingOrder.id}`, formData);
        setSuccess('Заказ успешно обновлен');
      } else {
        await axios.post(`${API_URL}/orders`, formData);
        setSuccess('Заказ успешно создан');
      }
      handleClose();
      fetchOrders();
    } catch (error) {
      setError('Ошибка при сохранении заказа');
      console.error('Ошибка при сохранении заказа:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
    if (window.confirm('Вы уверены, что хотите удалить этот заказ?')) {
      setLoading(true);
      try {
        await axios.delete(`${API_URL}/orders/${id}`);
        setSuccess('Заказ успешно удален');
        fetchOrders();
      } catch (error) {
        setError('Ошибка при удалении заказа');
        console.error('Ошибка при удалении заказа:', error);
      } finally {
        setLoading(false);
      }
    }
  };

  if (loading && !orders.length) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h4">Заказы</Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpen()}
        >
          Создать заказ
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Номер</TableCell>
              <TableCell>Тип</TableCell>
              <TableCell>Поставщик</TableCell>
              <TableCell>Статус</TableCell>
              <TableCell>Дата создания</TableCell>
              <TableCell>Действия</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {orders.map((order) => (
              <TableRow key={order.id}>
                <TableCell>#{order.id}</TableCell>
                <TableCell>
                  <Chip
                    label={ORDER_TYPES[order.type]?.label}
                    color={ORDER_TYPES[order.type]?.color}
                    size="small"
                  />
                </TableCell>
                <TableCell>{order.supplier_name}</TableCell>
                <TableCell>
                  <Chip
                    label={ORDER_STATUSES[order.status]?.label}
                    color={ORDER_STATUSES[order.status]?.color}
                    size="small"
                  />
                </TableCell>
                <TableCell>
                  {new Date(order.created_at).toLocaleString()}
                </TableCell>
                <TableCell>
                  <IconButton onClick={() => handleOpen(order)} color="primary">
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(order.id)} color="error">
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      <Dialog open={open} onClose={handleClose} maxWidth="sm" fullWidth>
        <DialogTitle>
          {editingOrder ? 'Редактировать заказ' : 'Создать заказ'}
        </DialogTitle>
        <Box component="form" onSubmit={handleSubmit}>
          <DialogContent>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Тип заказа</InputLabel>
                  <Select
                    value={formData.type}
                    onChange={(e) => setFormData({ ...formData, type: e.target.value })}
                    label="Тип заказа"
                    disabled={loading}
                  >
                    <MenuItem value="incoming">Входящий</MenuItem>
                    <MenuItem value="outgoing">Исходящий</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Поставщик</InputLabel>
                  <Select
                    value={formData.supplier_id}
                    onChange={(e) => setFormData({ ...formData, supplier_id: e.target.value })}
                    label="Поставщик"
                    disabled={loading}
                  >
                    {suppliers.map((supplier) => (
                      <MenuItem key={supplier.id} value={supplier.id}>
                        {supplier.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <FormControl fullWidth>
                  <InputLabel>Статус</InputLabel>
                  <Select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                    label="Статус"
                    disabled={loading}
                  >
                    <MenuItem value="pending">В ожидании</MenuItem>
                    <MenuItem value="processing">В обработке</MenuItem>
                    <MenuItem value="completed">Завершен</MenuItem>
                    <MenuItem value="cancelled">Отменен</MenuItem>
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={12}>
                <TextField
                  label="Примечания"
                  fullWidth
                  multiline
                  rows={4}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  disabled={loading}
                />
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose} disabled={loading}>Отмена</Button>
            <Button 
              type="submit" 
              variant="contained" 
              color="primary"
              disabled={loading}
            >
              {loading ? <CircularProgress size={24} /> : (editingOrder ? 'Сохранить' : 'Создать')}
            </Button>
          </DialogActions>
        </Box>
      </Dialog>

      <Snackbar open={!!error} autoHideDuration={6000} onClose={() => setError(null)}>
        <Alert onClose={() => setError(null)} severity="error">
          {error}
        </Alert>
      </Snackbar>

      <Snackbar open={!!success} autoHideDuration={6000} onClose={() => setSuccess(null)}>
        <Alert onClose={() => setSuccess(null)} severity="success">
          {success}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default OrderList; 