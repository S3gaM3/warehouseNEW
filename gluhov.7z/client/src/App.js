import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './components/auth/Login';
import Navigation from './components/Navigation';
import ProductList from './components/products/ProductList';
import ProductForm from './components/products/ProductForm';
import CategoryList from './components/CategoryList';
import SupplierList from './components/SupplierList';
import OrderList from './components/OrderList';
import WarehouseDashboard from './components/WarehouseDashboard';
import MovementList from './components/MovementList';
import ReportDashboard from './components/ReportDashboard';
import EmployeeList from './components/EmployeeList';
import InvoiceList from './components/InvoiceList';
import Settings from './components/Settings';

const PrivateRoute = ({ children }) => {
    const token = localStorage.getItem('token');
    return token ? (
        <div className="min-h-screen bg-gray-100">
            <div className="flex">
                <Navigation />
                <main className="flex-1 p-8">{children}</main>
            </div>
        </div>
    ) : (
        <Navigate to="/login" />
    );
};

const App = () => {
    return (
        <Router>
            <div className="min-h-screen bg-gray-100">
                <Routes>
                    <Route path="/login" element={<Login />} />
                    <Route
                        path="/products"
                        element={
                            <PrivateRoute>
                                <ProductList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/products/new"
                        element={
                            <PrivateRoute>
                                <ProductForm />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/products/:id/edit"
                        element={
                            <PrivateRoute>
                                <ProductForm />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/categories"
                        element={
                            <PrivateRoute>
                                <CategoryList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/suppliers"
                        element={
                            <PrivateRoute>
                                <SupplierList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/orders"
                        element={
                            <PrivateRoute>
                                <OrderList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/warehouse"
                        element={
                            <PrivateRoute>
                                <WarehouseDashboard />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/movements"
                        element={
                            <PrivateRoute>
                                <MovementList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/reports"
                        element={
                            <PrivateRoute>
                                <ReportDashboard />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/employees"
                        element={
                            <PrivateRoute>
                                <EmployeeList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/invoices"
                        element={
                            <PrivateRoute>
                                <InvoiceList />
                            </PrivateRoute>
                        }
                    />
                    <Route
                        path="/settings"
                        element={
                            <PrivateRoute>
                                <Settings />
                            </PrivateRoute>
                        }
                    />
                    <Route path="/" element={<Navigate to="/products" />} />
                </Routes>
            </div>
        </Router>
    );
};

export default App;
