import api from './config';

export const getSummary = async () => {
    const response = await api.get('/reports/summary');
    return response.data;
};

export const getSalesReport = async (period) => {
    const response = await api.get('/reports/sales', { params: { period } });
    return response.data;
};

export const getInventoryReport = async () => {
    const response = await api.get('/reports/inventory');
    return response.data;
};

export const getCategoryReport = async () => {
    const response = await api.get('/reports/categories');
    return response.data;
};

export const getProductReport = async () => {
    const response = await api.get('/reports/products');
    return response.data;
}; 