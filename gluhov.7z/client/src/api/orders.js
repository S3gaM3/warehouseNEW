import api from './config';

export const getOrders = async () => {
    const response = await api.get('/orders');
    return response.data;
};

export const getOrder = async (id) => {
    const response = await api.get(`/orders/${id}`);
    return response.data;
};

export const createOrder = async (order) => {
    const response = await api.post('/orders', order);
    return response.data;
};

export const updateOrder = async (id, order) => {
    const response = await api.put(`/orders/${id}`, order);
    return response.data;
};

export const deleteOrder = async (id) => {
    const response = await api.delete(`/orders/${id}`);
    return response.data;
};

export const getOrderItems = async (orderId) => {
    const response = await api.get(`/orders/${orderId}/items`);
    return response.data;
};

export const addOrderItem = async (orderId, item) => {
    const response = await api.post(`/orders/${orderId}/items`, item);
    return response.data;
};

export const updateOrderItem = async (orderId, itemId, item) => {
    const response = await api.put(`/orders/${orderId}/items/${itemId}`, item);
    return response.data;
};

export const deleteOrderItem = async (orderId, itemId) => {
    const response = await api.delete(`/orders/${orderId}/items/${itemId}`);
    return response.data;
}; 