import api from './config';

export const getInvoices = async () => {
    const response = await api.get('/invoices');
    return response.data;
};

export const getInvoice = async (id) => {
    const response = await api.get(`/invoices/${id}`);
    return response.data;
};

export const createInvoice = async (invoice) => {
    const response = await api.post('/invoices', invoice);
    return response.data;
};

export const updateInvoice = async (id, invoice) => {
    const response = await api.put(`/invoices/${id}`, invoice);
    return response.data;
};

export const deleteInvoice = async (id) => {
    const response = await api.delete(`/invoices/${id}`);
    return response.data;
};

export const getInvoiceItems = async (invoiceId) => {
    const response = await api.get(`/invoices/${invoiceId}/items`);
    return response.data;
};

export const addInvoiceItem = async (invoiceId, item) => {
    const response = await api.post(`/invoices/${invoiceId}/items`, item);
    return response.data;
};

export const updateInvoiceItem = async (invoiceId, itemId, item) => {
    const response = await api.put(`/invoices/${invoiceId}/items/${itemId}`, item);
    return response.data;
};

export const deleteInvoiceItem = async (invoiceId, itemId) => {
    const response = await api.delete(`/invoices/${invoiceId}/items/${itemId}`);
    return response.data;
};

export const printInvoice = async (id) => {
    const response = await api.get(`/invoices/${id}/print`, {
        responseType: 'blob'
    });
    return response.data;
}; 