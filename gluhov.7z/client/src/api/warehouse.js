import api from './config';

export const getStockMovements = async () => {
    const response = await api.get('/warehouse/movements');
    return response.data;
};

export const getStockMovement = async (id) => {
    const response = await api.get(`/warehouse/movements/${id}`);
    return response.data;
};

export const createStockMovement = async (movement) => {
    const response = await api.post('/warehouse/movements', movement);
    return response.data;
};

export const updateStockMovement = async (id, movement) => {
    const response = await api.put(`/warehouse/movements/${id}`, movement);
    return response.data;
};

export const deleteStockMovement = async (id) => {
    const response = await api.delete(`/warehouse/movements/${id}`);
    return response.data;
};

export const getInventory = async () => {
    const response = await api.get('/warehouse/inventory');
    return response.data;
};

export const getProductInventory = async (productId) => {
    const response = await api.get(`/warehouse/inventory/${productId}`);
    return response.data;
}; 