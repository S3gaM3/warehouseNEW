import api from './config';

export const getMovements = async () => {
    const response = await api.get('/warehouse/movements');
    return response.data;
};

export const createMovement = async (movementData) => {
    const response = await api.post('/warehouse/movements', movementData);
    return response.data;
};

export const updateMovement = async (id, movementData) => {
    const response = await api.put(`/warehouse/movements/${id}`, movementData);
    return response.data;
};

export const deleteMovement = async (id) => {
    const response = await api.delete(`/warehouse/movements/${id}`);
    return response.data;
}; 