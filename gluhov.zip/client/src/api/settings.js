import api from './config';

export const getSettings = async () => {
    const response = await api.get('/settings');
    return response.data;
};

export const updateSettings = async (settings) => {
    const response = await api.put('/settings', settings);
    return response.data;
};

export const getCompanyInfo = async () => {
    const response = await api.get('/settings/company');
    return response.data;
};

export const updateCompanyInfo = async (companyInfo) => {
    const response = await api.put('/settings/company', companyInfo);
    return response.data;
}; 